/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  Usuario
 * Created: 22 oct. 2024
 */

use Test;

insert into USUARIO (user_name,user_pass) values ( 'gerdoc', sha('gerdoc1234') );